// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Composite maroon layer"); }
int main(){
  announce();
  return lionss_run_workload("maroon");
}
