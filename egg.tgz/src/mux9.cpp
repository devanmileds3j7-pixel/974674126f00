// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Benchmark route match\n", stdout);
  return lionss_run_workload("mux9");
}
